./xtest -f=xtest.toml

# -f 指定配置文件.
# -v 输出版本信息.
# -h 输出帮助信息.