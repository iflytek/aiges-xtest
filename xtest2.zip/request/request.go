package request

import _var "xtest/var"

type Request struct {
	C _var.Conf
}
